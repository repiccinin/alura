package br.com.alura.screenmatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreenmatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
